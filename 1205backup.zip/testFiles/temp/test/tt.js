const mysql = require("mysql");
require("dotenv").config();

let con = mysql.createConnection({ //대소문자 구분해야됨
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE
});

con.connect(function(err){
        if(err) throw err;
        console.log("Database Connected!");
    
        let sQuery = "Select * from Product";
        con.query(sQuery, (err, result, fields)=>{
            if(err) console.error(err); //throw err;
            console.log(result);
            // console.log(fields);
        });
    con.end();
});