const express = require("express");
const app = express();

const pd = require("./tt.js");

app.get("/", (req, res)=>{
    
    res.render("index");
});

const port = 3000;
app.listen(port, ()=>{
    console.log(`app is running ${port}`);
});