const qr = require("./bs.js");


let sQuery = "select * from Admin";
qr.mquery(sQuery);