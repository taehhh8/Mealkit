const express = require("express");
// const nunjucks = require("nunjucks");
const logger = require("morgan");
const bodyParser = require("body-parser");

// const admin = require("./routes/admin");
// const mypage = require("./routes/mypage");
// const product = require("./routes/product");b

const app = express();
const port = 3001;

// app.use("/admin", greatestChk, admin);
// app.use("/mypage", mypage);
// app.use("/product", product);

app.set("view enging", "pug");
app.set("views", "./views");

// nunjucks.configure("views", {
//     autoscape: true, 
//     express : app //express를 담은 변수를 입력한다.
// });

app.use(logger("dev"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : false}));

app.get("/", (req, res)=>{
    let products = [{ title: "양파 치즈 마요 드레싱", name: "부드러운 닭가슴살 콥 샐러드(S)",            sale: ["10%", "5,800원"], price: "5,220원" },{ title: "참깨 마요 드레싱", name: "[I like Eat] 크랜베리 치킨 샐러드", sale: ["10%", "4,900원"], price: "4,410원" }, { title: "참깨 드레싱", name: "율무 단호박 샐러드(R)", sale: ["10%", "7,500원"], price: "6,750원" }, { title: "스위트 바나나 드레싱", name: "리코타 치즈 샐러드 (S/R)", sale: ["10%", "5,800원"], price: "5,220원" } ];

    
 res.render("index", {
     products : products
 });
});




app.listen(port, ()=>{
   console.log(`mini Server is running ---${port}---`) 
});