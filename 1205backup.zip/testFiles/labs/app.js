const express = require("express");
const app = express();


app.set("view engine", "pug");
app.set("views", "./views");


app.get("/", (req, res)=>{
    let products = [
        {title:"양파 치즈 마요 드레싱" , name:"부드러운 닭가슴살 콥 샐러드 (S)" , sale:[ "10%",  "5,800원"], price:"5,220원"},
        {title:"참깨 마요 드레싱" , name:"[I like Eat] 크랜베리 치킨 샐러드" , sale:[ "10%",  "5,800원"], price:"5,220원"},
        {title:"참깨 드레싱" , name:"율무 단호박 샐러드(R)" , sale:[ "10%",  "5,800원"], price:"5,220원"},
        {title:"스위트 바나나 드레싱" , name:"리코타 치즈 샐러드 (S/R)" , sale:[ "10%",  "5,800원"], price:"5,220원"}
                   ]
    res.render("index", {products : products});
});


const port = 3001;
app.listen(port, ()=>{
    console.log(`miniapp is running ---${port}`);
})