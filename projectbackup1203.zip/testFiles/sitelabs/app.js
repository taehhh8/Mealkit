const express = require("express");
const nunjucks = require("nunjucks");
const logger = require("morgan");
const bodyParser = require("body-parser");

// const admin = require("./routes/admin");
// const mypage = require("./routes/mypage");
// const product = require("./routes/product");

const app = express();
const port = 3001;

// app.use("/admin", greatestChk, admin);
// app.use("/mypage", mypage);
// app.use("/product", product);

nunjucks.configure("views", {
    autoscape: true, 
    express : app //express를 담은 변수를 입력한다.
});

app.use(logger("dev"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : false}));

app.get("/", (req, res)=>{
   
    
 res.send("Mic Test");
});




app.listen(port, ()=>{
   console.log(`mini Server is running ---${port}---`) 
});