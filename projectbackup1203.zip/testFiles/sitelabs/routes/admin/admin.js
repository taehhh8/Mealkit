const express = require("express");
const router = express.Router();

function chk( req, res, next){
   
    next();
}
router.get("/", chk, (req, res)=>{
   
    res.send("admin ok")
});

module.exports = router;